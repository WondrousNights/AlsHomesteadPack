This mod would have not been possible without the help of countless other people. We stand on the shoulders of giants!

Thank you,

~Tels & Phiwa

## Thank you

First and foremost a big thank you goes to **Saraty**, **Tyron** and all the other
team members for creating such a great game!

### Testing, Feedback and Bugreporting

* **anyanana**

### Translators

* English advisors: **Ashantin**, **jjallie1**
* German: **Tels**, **Phiwa**
* French: **Wailwolf**
* Japanese: **Macoto Hino**
* Polish: **Gengaroshi**
* Ukrainian: **DeanBro**
* Russian: **Morok**
* Spanish: **Ruddi**, **SkyTheSkunny**

### Modding help

* All the people answering questions, on the modding-help discord channel or elsewere: You are awesome!
Especially:
  + **Capsup**
  + **DArkHekRoMaNT**
  + **JapanHasRice**
  + **l33tmaan**
  + **pizza2004** - You are a legend!
  + **Radfast**
  + **SpearAndFang**

### Resources

The background image in the title card comes from [GetWallPapers](https://getwallpapers.com/)

