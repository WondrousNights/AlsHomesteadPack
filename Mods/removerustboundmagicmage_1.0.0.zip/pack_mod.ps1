# Get the current directory
$currentDir = Get-Location

# Read modinfo.json
if (-not (Test-Path "modinfo.json")) {
    Write-Error "modinfo.json not found in the current directory."
    exit 1
}

$modInfo = Get-Content "modinfo.json" | ConvertFrom-Json
$modId = $modInfo.modid
$version = $modInfo.version

if (-not $modId -or -not $version) {
    Write-Error "Could not read modid or version from modinfo.json."
    exit 1
}

$zipName = "${modId}_${version}.zip"
$destination = "$env:APPDATA\VintagestoryData\Mods\$zipName"

# Remove existing zip if it exists in the current folder
if (Test-Path $zipName) {
    Remove-Item $zipName
}

# Get all items in the current directory to zip, excluding the script itself and any existing zip
$itemsToZip = Get-ChildItem -Path $currentDir | Where-Object { 
    $_.Name -ne $MyInvocation.MyCommand.Name -and 
    $_.Name -ne $zipName -and
    $_.Name -ne ".git" -and
    $_.Name -ne ".vscode"
}

# Create the zip file
Compress-Archive -Path $itemsToZip.FullName -DestinationPath $zipName -Force

# Copy to Mods folder
Copy-Item $zipName -Destination $destination -Force

Write-Host "Mod packed as $zipName and installed to $destination"
